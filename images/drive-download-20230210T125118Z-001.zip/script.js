		//Will popup that good day message
		let scroll = document.getElementById('scroll')
		window.addEventListener('scroll', displayShow);
		function displayShow() {
			if (window.pageYOffset > 100) {
				scroll.setAttribute('style', "opacity:1;position:fixed;")
			}
			else {
				scroll.setAttribute('style', "display:none;")
			}
		}




		//Will change background images or will make popup
{
		var imgMenu = document.getElementById('dynamic-image-menu');
		let body = document.body;
		clickEvent(0,BF);
		clickEvent(1,RYT);
		clickEvent(2,IH);
		clickEvent(3,TMMS);
		clickEvent(4,NG);
		clickEvent(5,MG);
		clickEvent(6,A);
		function clickEvent(childrenNo,funcName){
			imgMenu.children[childrenNo].addEventListener('click',funcName);
		}
		let featuresForPopup = 'height=400px,width=450px'
		 imgMenu.children[7].addEventListener('click', () => window.open('https://www.youtube.com/watch?v=gT8Mn0WOK6k&list=RDMMgT8Mn0WOK6k&index=1', 'Youtube1', featuresForPopup))
		 imgMenu.children[7].addEventListener('contextmenu',() => window.open('https://www.youtube.com/watch?v=XnYwxghBogc&list=RDMMgT8Mn0WOK6k&index=3', 'Youtube2', featuresForPopup))
		function BackgroundImg(link,size='cover',position){
			body.setAttribute('style',`background:url("${link}");background-size:${size};background-position:${position}`);
			console.log('ok');
		}

}

		    //functions to call BackgroundImg function wil also be used for changinging background ATQ random no.
		function BF(){BackgroundImg('images/blue fight.jpg','cover','center')}
	    function RYT(){BackgroundImg('images/RYT.png','cover','right')}
		function IH() {BackgroundImg('images/in heaven.png','cover','right')}
		function TMMS() {BackgroundImg('images/that marry me song.png','cover','bottom')}
		function NG() {BackgroundImg('https://wallpaperaccess.com/full/6574022.jpg','cover','center')}
		function MG() {BackgroundImg('images/mikeGirl.jpg','cover','center');}
		function A() {
		 	if (window.innerWidth<=690){
				BackgroundImg('images/Aayaka.jpg','cover','');
		 }else{
			BackgroundImg('images/that marry me song.png','cover','center');
		 }
		 }

{
		function Random(min,max){
			let random = Math.floor(Math.random()*(max-min)+min);
			return random;
		}
 		let timeout
		imgMenu.children[6].oncontextmenu = () => timeout = window.setInterval(backgroundATQrandom,4000);
		imgMenu.children[5].oncontextmenu = () => window.clearInterval(timeout)

		function backgroundATQrandom(){
			let random = Random(0,6)
			switch(random){
				case 0: BF();
				break;
				case 1: RYT();
				break;
				case 2: IH();
				break;
				case 3: TMMS();
				break;
				case 4: NG();
				break;
				case 5: MG();
				break;
				case 6: A();
			}
			console.log(random);
		}

}
{
		//Will change images of imge box
		let numbering = 0;
		slideshow(numbering)
		function controller(imgNo){
			numbering = numbering + imgNo;
			slideshow(numbering);
			console.log(numbering)
		}
		
		function slideshow(funcNum){
			let slides = document.getElementsByClassName('slideImages');
			if (funcNum==slides.length){
				funcNum=0;
				numbering=0;
			}
			if (funcNum<0){
				funcNum=slides.length-1;
				numbering=slides.length-1;
			}
			for(let every of slides){
				every.style.display = 'none';
			}
			slides[funcNum].style.display='block'
		}
}